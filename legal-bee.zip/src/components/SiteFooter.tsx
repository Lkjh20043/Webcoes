import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-sm bg-gradient-honey">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-primary" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M12 2 L21 7 V17 L12 22 L3 17 V7 Z" />
                <path d="M8 10h8M8 14h8" />
              </svg>
            </span>
            <span className="font-display text-lg font-bold">Legal Bee</span>
          </div>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-primary-foreground/70">
            Premier legal &amp; business consulting in New Delhi. We simplify company registration,
            compliance, IP and contracts for founders and growing businesses across India.
          </p>
        </div>

        <div>
          <h4 className="font-display text-sm font-semibold text-honey">Explore</h4>
          <ul className="mt-4 space-y-2 text-sm text-primary-foreground/70">
            <li><Link to="/services" className="hover:text-honey">Services</Link></li>
            <li><Link to="/about" className="hover:text-honey">About</Link></li>
            <li><Link to="/contact" className="hover:text-honey">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm font-semibold text-honey">Reach Us</h4>
          <ul className="mt-4 space-y-2 text-sm text-primary-foreground/70">
            <li>New Delhi, India</li>
            <li>hello@legalbee.in</li>
            <li>+91 11 0000 0000</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-2 px-6 py-6 text-xs text-primary-foreground/50 md:flex-row md:items-center">
          <span>© {new Date().getFullYear()} Legal Bee Business Solutions LLP. All rights reserved.</span>
          <span>Serving Delhi NCR, Mumbai, Pune, Bengaluru, Chennai, Hyderabad, Kolkata &amp; beyond.</span>
        </div>
      </div>
    </footer>
  );
}