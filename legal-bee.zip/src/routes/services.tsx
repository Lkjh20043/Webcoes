import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Company Registration, GST, IP & Compliance | Legal Bee" },
      { name: "description", content: "Full suite of legal & business services: Pvt Ltd / LLP / OPC registration, GST, MSME, trademark, copyright, contracts, ROC filings and startup advisory." },
      { property: "og:title", content: "Legal Bee Services" },
      { property: "og:description", content: "Company registration, GST, MSME, trademark, contracts, ROC compliance and startup advisory." },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: Services,
});

const groups = [
  {
    label: "Start your company",
    items: [
      { t: "Private Limited Company", d: "MoA/AoA drafting, DIN, DSC, name approval, certificate of incorporation." },
      { t: "Limited Liability Partnership (LLP)", d: "Designated partner KYC, LLP agreement, MCA filing." },
      { t: "One Person Company (OPC)", d: "Sole-founder structure with limited liability and easy conversion." },
      { t: "Partnership & Sole Proprietorship", d: "Deed drafting, registration and PAN/TAN setup." },
    ],
  },
  {
    label: "Tax & registrations",
    items: [
      { t: "GST Registration & Returns", d: "GSTIN application, monthly/quarterly filings, reconciliations." },
      { t: "MSME / Udyam Certification", d: "Eligibility review and Udyam portal registration." },
      { t: "Import-Export Code", d: "IEC application for cross-border trade." },
      { t: "Shops & Establishment / Professional Tax", d: "State-level registrations across India." },
    ],
  },
  {
    label: "Intellectual property",
    items: [
      { t: "Trademark Search & Filing", d: "Class identification, search reports, TM-A filing, prosecution." },
      { t: "Copyright Registration", d: "Literary, artistic, software and audiovisual works." },
      { t: "Trademark Objections & Oppositions", d: "Reply drafting and hearings before the Registrar." },
    ],
  },
  {
    label: "Contracts & advisory",
    items: [
      { t: "Contract Drafting & Review", d: "NDAs, MSAs, employment, vendor, SaaS, founders' agreements." },
      { t: "Startup Legal Advisory", d: "Cap-table support, term-sheet review, ESOP plans, fundraising prep." },
      { t: "ROC & Annual Compliance", d: "Board resolutions, statutory registers, annual returns and audits." },
      { t: "Legal Opinions", d: "Regulatory opinions on sector-specific questions." },
    ],
  },
];

function Services() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />

      <section className="bg-gradient-hero text-primary-foreground">
        <div className="mx-auto max-w-5xl px-6 py-24 md:py-28">
          <span className="text-xs uppercase tracking-[0.22em] text-honey">Services</span>
          <h1 className="mt-4 font-display text-4xl font-bold leading-tight text-balance md:text-6xl">
            Every legal capability your business will ever need.
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-primary-foreground/75">
            Fixed-fee, transparently scoped, delivered on a clear timeline — across India.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-24 space-y-20">
        {groups.map((g, gi) => (
          <div key={g.label} className="grid gap-10 md:grid-cols-12">
            <div className="md:col-span-4">
              <div className="text-xs uppercase tracking-[0.22em] text-accent-foreground/60">0{gi + 1}</div>
              <h2 className="mt-3 font-display text-3xl font-bold text-primary leading-tight">{g.label}</h2>
            </div>
            <div className="grid gap-px overflow-hidden rounded-md border border-border bg-border md:col-span-8 md:grid-cols-2">
              {g.items.map((i) => (
                <div key={i.t} className="bg-card p-6">
                  <h3 className="font-display text-lg font-semibold text-primary">{i.t}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{i.d}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </section>

      <section className="bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-col items-start gap-6 px-6 py-16 md:flex-row md:items-center md:justify-between">
          <h2 className="font-display text-2xl font-bold text-primary md:text-3xl text-balance">
            Need something custom? We probably handle it.
          </h2>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-sm bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant"
          >
            Request a quote →
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}