import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Legal Bee Business Solutions LLP" },
      { name: "description", content: "Get in touch with Legal Bee for company registration, GST, trademark, contracts and compliance support. Based in New Delhi, serving India." },
      { property: "og:title", content: "Contact Legal Bee" },
      { property: "og:description", content: "Book a free consultation with our legal & business advisory team." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <SiteNav />

      <section className="mx-auto grid max-w-7xl gap-16 px-6 py-20 md:grid-cols-2 md:py-28">
        <div>
          <span className="text-xs uppercase tracking-[0.22em] text-muted-foreground">Get in touch</span>
          <h1 className="mt-3 font-display text-4xl font-bold leading-tight text-primary md:text-5xl text-balance">
            Tell us about your business. We'll respond within 24 hours.
          </h1>
          <p className="mt-6 text-muted-foreground leading-relaxed">
            Whether you're incorporating your first company or need ongoing compliance support,
            our team in New Delhi is ready to help.
          </p>

          <dl className="mt-10 space-y-6">
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent-foreground/60">Office</dt>
              <dd className="mt-1 font-display text-lg text-primary">New Delhi, India</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent-foreground/60">Email</dt>
              <dd className="mt-1 font-display text-lg text-primary">
                <a href="mailto:hello@legalbee.in" className="hover:text-accent">hello@legalbee.in</a>
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-accent-foreground/60">Phone</dt>
              <dd className="mt-1 font-display text-lg text-primary">+91 11 0000 0000</dd>
            </div>
          </dl>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
          }}
          className="rounded-md border border-border bg-card p-8 shadow-elegant"
        >
          {sent ? (
            <div className="flex h-full min-h-[420px] flex-col items-center justify-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-honey text-primary">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12l5 5L20 7" /></svg>
              </div>
              <h3 className="mt-5 font-display text-2xl font-bold text-primary">Message received.</h3>
              <p className="mt-2 text-sm text-muted-foreground">A Legal Bee advisor will reach out within one business day.</p>
            </div>
          ) : (
            <div className="space-y-5">
              <Field label="Full name" name="name" required />
              <Field label="Work email" name="email" type="email" required />
              <Field label="Phone (optional)" name="phone" />
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-primary">Service</label>
                <select className="mt-2 w-full rounded-sm border border-input bg-background px-4 py-3 text-sm focus:border-accent focus:outline-none">
                  <option>Company registration</option>
                  <option>GST / MSME</option>
                  <option>Trademark / IP</option>
                  <option>Contract drafting</option>
                  <option>ROC / annual compliance</option>
                  <option>Startup advisory</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-primary">How can we help?</label>
                <textarea
                  rows={4}
                  className="mt-2 w-full rounded-sm border border-input bg-background px-4 py-3 text-sm focus:border-accent focus:outline-none"
                />
              </div>
              <button
                type="submit"
                className="w-full rounded-sm bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:-translate-y-0.5 transition-transform"
              >
                Request consultation
              </button>
              <p className="text-xs text-muted-foreground">By submitting, you agree to be contacted about your enquiry.</p>
            </div>
          )}
        </form>
      </section>

      <SiteFooter />
    </div>
  );
}

function Field({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label htmlFor={name} className="block text-xs font-semibold uppercase tracking-wider text-primary">{label}</label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        className="mt-2 w-full rounded-sm border border-input bg-background px-4 py-3 text-sm focus:border-accent focus:outline-none"
      />
    </div>
  );
}