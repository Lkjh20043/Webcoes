import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import heroImage from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Legal Bee — Company Registration, GST & Compliance in India" },
      { name: "description", content: "New Delhi-based legal & business consulting. Pvt Ltd / LLP / OPC registration, GST, MSME, trademark, ROC filings and startup advisory across India." },
      { property: "og:title", content: "Legal Bee — Legal & Business Consulting in India" },
      { property: "og:description", content: "Company registration, GST, trademark, ROC compliance and startup advisory. Serving businesses pan-India." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LegalService",
          name: "Legal Bee Business Solutions LLP",
          description: "Legal and business consulting firm in New Delhi specializing in company registration, GST, compliance, trademark and startup advisory.",
          address: { "@type": "PostalAddress", addressLocality: "New Delhi", addressCountry: "IN" },
          areaServed: ["Delhi", "Maharashtra", "Karnataka", "Gujarat", "Tamil Nadu", "Uttar Pradesh", "Haryana", "West Bengal", "Telangana"],
        }),
      },
    ],
  }),
  component: Index,
});

const services = [
  { title: "Company Registration", desc: "Pvt Ltd, LLP, OPC, Partnership & Section 8 incorporations end-to-end.", icon: "M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6" },
  { title: "GST & MSME", desc: "Registration, returns, advisory and Udyam / MSME certification.", icon: "M4 7h16M4 12h16M4 17h10" },
  { title: "Trademark & Copyright", desc: "Search, filing and prosecution to protect your brand and IP.", icon: "M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z" },
  { title: "Contract Drafting", desc: "Founders' agreements, NDAs, SaaS, employment and vendor contracts.", icon: "M8 4h9l4 4v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM9 12h8M9 16h6M9 8h4" },
  { title: "ROC & Annual Compliance", desc: "Annual filings, board resolutions, statutory registers — all on time.", icon: "M3 4h18v4H3zM3 12h18v4H3zM3 20h12" },
  { title: "Startup Legal Advisory", desc: "Fundraising support, ESOPs, term-sheet review and growth-stage counsel.", icon: "M13 2 3 14h7l-1 8 10-12h-7z" },
];

const locations = [
  { state: "Delhi NCR", cities: "New Delhi · Gurugram · Noida" },
  { state: "Maharashtra", cities: "Mumbai · Pune" },
  { state: "Karnataka", cities: "Bengaluru" },
  { state: "Tamil Nadu", cities: "Chennai" },
  { state: "Telangana", cities: "Hyderabad" },
  { state: "West Bengal", cities: "Kolkata" },
  { state: "Gujarat", cities: "Ahmedabad · Surat" },
  { state: "Uttar Pradesh", cities: "Lucknow · Kanpur" },
];

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />

      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-hero text-primary-foreground">
        <div
          className="absolute inset-0 opacity-40"
          style={{ backgroundImage: `url(${heroImage})`, backgroundSize: "cover", backgroundPosition: "center" }}
          aria-hidden
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/85 to-transparent" aria-hidden />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-24 md:grid-cols-12 md:py-32">
          <div className="md:col-span-7">
            <span className="inline-flex items-center gap-2 rounded-full border border-honey/40 bg-primary/40 px-4 py-1.5 text-xs uppercase tracking-[0.18em] text-honey">
              <span className="h-1.5 w-1.5 rounded-full bg-honey" /> New Delhi · Pan-India
            </span>
            <h1 className="mt-6 font-display text-4xl font-bold leading-[1.1] text-balance md:text-6xl">
              Legal clarity for <span className="text-honey">ambitious businesses</span>.
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-primary-foreground/75 md:text-lg">
              From incorporation to compliance, IP to contracts — Legal Bee is the trusted legal &
              business consulting partner for founders and growing enterprises across India.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-sm bg-gradient-honey px-7 py-3.5 text-sm font-semibold text-primary shadow-honey transition-transform hover:-translate-y-0.5"
              >
                Book a free consultation →
              </Link>
              <Link
                to="/services"
                className="inline-flex items-center gap-2 rounded-sm border border-primary-foreground/30 px-7 py-3.5 text-sm font-medium text-primary-foreground hover:bg-primary-foreground/10"
              >
                Explore services
              </Link>
            </div>

            <dl className="mt-14 grid max-w-lg grid-cols-3 gap-8 border-t border-primary-foreground/15 pt-8">
              <div>
                <dt className="text-xs uppercase tracking-wider text-honey/80">Clients</dt>
                <dd className="mt-1 font-display text-2xl font-bold">800+</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wider text-honey/80">States</dt>
                <dd className="mt-1 font-display text-2xl font-bold">12</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-wider text-honey/80">Filings</dt>
                <dd className="mt-1 font-display text-2xl font-bold">5K+</dd>
              </div>
            </dl>
          </div>
        </div>
      </section>

      {/* SERVICES GRID */}
      <section id="services" className="honeycomb-bg">
        <div className="mx-auto max-w-7xl px-6 py-24">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <span className="text-xs uppercase tracking-[0.22em] text-muted-foreground">What we do</span>
              <h2 className="mt-3 max-w-2xl font-display text-3xl font-bold leading-tight md:text-5xl">
                End-to-end legal &amp; compliance, handled.
              </h2>
            </div>
            <p className="max-w-sm text-sm text-muted-foreground">
              One firm for every legal need as your company grows — from day-zero incorporation
              to mature governance.
            </p>
          </div>

          <div className="mt-14 grid gap-px overflow-hidden rounded-md border border-border bg-border md:grid-cols-2 lg:grid-cols-3">
            {services.map((s) => (
              <article key={s.title} className="group relative bg-card p-8 transition-colors hover:bg-parchment">
                <div className="flex h-12 w-12 items-center justify-center rounded-sm bg-honey-soft text-primary transition-colors group-hover:bg-gradient-honey">
                  <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d={s.icon} />
                  </svg>
                </div>
                <h3 className="mt-6 font-display text-xl font-bold text-primary">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
                <Link to="/services" className="mt-6 inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-secondary hover:text-accent">
                  Learn more →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className="bg-primary text-primary-foreground">
        <div className="mx-auto grid max-w-7xl gap-16 px-6 py-24 md:grid-cols-12">
          <div className="md:col-span-5">
            <span className="text-xs uppercase tracking-[0.22em] text-honey">Why Legal Bee</span>
            <h2 className="mt-3 font-display text-3xl font-bold leading-tight md:text-4xl">
              A boutique team with the rigor of a top-tier firm.
            </h2>
            <p className="mt-6 text-primary-foreground/70 leading-relaxed">
              We pair deep regulatory expertise with founder-first thinking — so you get advice that
              actually moves the business forward, not just paper that satisfies the registry.
            </p>
          </div>
          <div className="grid gap-8 md:col-span-7 md:grid-cols-2">
            {[
              { t: "Transparent pricing", d: "Fixed-fee packages with no surprise invoices." },
              { t: "Pan-India coverage", d: "Filings handled across every state ROC and tax jurisdiction." },
              { t: "Single point of contact", d: "A named lead consultant for your entire engagement." },
              { t: "Always on time", d: "Compliance calendars and reminders so deadlines never slip." },
            ].map((b) => (
              <div key={b.t} className="border-t border-honey/30 pt-5">
                <h3 className="font-display text-lg font-semibold text-honey">{b.t}</h3>
                <p className="mt-2 text-sm text-primary-foreground/70 leading-relaxed">{b.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LOCATIONS */}
      <section className="bg-background">
        <div className="mx-auto max-w-7xl px-6 py-24">
          <div className="max-w-2xl">
            <span className="text-xs uppercase tracking-[0.22em] text-muted-foreground">Where we work</span>
            <h2 className="mt-3 font-display text-3xl font-bold leading-tight md:text-4xl">
              Headquartered in New Delhi. Serving businesses across India.
            </h2>
          </div>
          <div className="mt-12 grid gap-px overflow-hidden rounded-md border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
            {locations.map((l) => (
              <div key={l.state} className="bg-card p-6">
                <div className="font-display text-base font-bold text-primary">{l.state}</div>
                <div className="mt-1 text-xs text-muted-foreground">{l.cities}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-parchment">
        <div className="mx-auto flex max-w-5xl flex-col items-start gap-8 px-6 py-20 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="font-display text-3xl font-bold leading-tight text-primary md:text-4xl text-balance">
              Ready to register, comply, or scale?
            </h2>
            <p className="mt-3 max-w-xl text-muted-foreground">
              Tell us about your business in 2 minutes. We'll come back with a clear scope and quote within 24 hours.
            </p>
          </div>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 rounded-sm bg-primary px-8 py-4 text-sm font-semibold text-primary-foreground shadow-elegant transition-transform hover:-translate-y-0.5"
          >
            Start the conversation →
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
