import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Legal Bee Business Solutions LLP" },
      { name: "description", content: "Meet Legal Bee — a New Delhi based boutique legal & business consulting firm helping founders incorporate, comply and scale across India." },
      { property: "og:title", content: "About Legal Bee" },
      { property: "og:description", content: "A boutique legal & business consulting firm in New Delhi serving clients across India." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: About,
});

function About() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />
      <section className="bg-gradient-hero text-primary-foreground">
        <div className="mx-auto max-w-5xl px-6 py-24 md:py-32">
          <span className="text-xs uppercase tracking-[0.22em] text-honey">About us</span>
          <h1 className="mt-4 font-display text-4xl font-bold leading-tight text-balance md:text-6xl">
            We translate Indian law into business outcomes.
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-primary-foreground/75 leading-relaxed">
            Legal Bee Business Solutions LLP is a New Delhi based legal & business consulting firm.
            For over a decade, our team has supported entrepreneurs, startups and established
            companies through every stage of their legal lifecycle — incorporation, taxation,
            intellectual property, contracts and corporate governance.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-16 px-6 py-24 md:grid-cols-2">
        <div>
          <h2 className="font-display text-3xl font-bold text-primary">Our mission</h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">
            To make compliant, strategic legal infrastructure accessible to every Indian business —
            from a first-time founder in Bengaluru to a manufacturing group in Gujarat. We believe
            good legal counsel should accelerate businesses, not slow them down.
          </p>
        </div>
        <div>
          <h2 className="font-display text-3xl font-bold text-primary">Our approach</h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">
            We combine the regulatory depth of senior practitioners with a modern, tech-enabled
            workflow. Every client gets a named lead, fixed-fee scoping, and a compliance calendar
            so nothing slips. No jargon, no surprises — just clear, accountable execution.
          </p>
        </div>
      </section>

      <section className="bg-primary text-primary-foreground">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 py-20 md:grid-cols-4">
          {[
            { v: "10+", l: "Years of practice" },
            { v: "800+", l: "Companies served" },
            { v: "12", l: "States covered" },
            { v: "5,000+", l: "Filings completed" },
          ].map((s) => (
            <div key={s.l}>
              <div className="font-display text-4xl font-bold text-honey">{s.v}</div>
              <div className="mt-2 text-sm uppercase tracking-wider text-primary-foreground/60">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h2 className="font-display text-3xl font-bold text-primary md:text-4xl">
          Let's build something compliant — and unstoppable.
        </h2>
        <Link
          to="/contact"
          className="mt-8 inline-flex items-center gap-2 rounded-sm bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:-translate-y-0.5 transition-transform"
        >
          Talk to our team →
        </Link>
      </section>

      <SiteFooter />
    </div>
  );
}